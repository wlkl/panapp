#!/usr/bin/env python3

from socket import *
import ipaddress

net = ipaddress.ip_network('192.168.2.0/24')
net2 = ('192.168.2.27', '192.168.2.70')

for i in net.hosts():
    s = socket(AF_INET, SOCK_STREAM)
    s.settimeout(0.1)
    res = s.connect_ex((str(i), 23))
    if res == 0:
        print(i, '-', s.connect_ex((str(i), 23)))
    s.close()
